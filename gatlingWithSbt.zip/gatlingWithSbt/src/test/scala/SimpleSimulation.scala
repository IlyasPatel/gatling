

import io.gatling.core.scenario.Simulation
import io.gatling.core.Predef._
import io.gatling.http.Predef._


class SimpleSimulation extends Simulation {

  // General configuration
  private val httpConfig = http.baseURL("http://computer-database.gatling.io")

  // Steps to execute
  private val scn = scenario("SimpleSimulation").
    exec(http("open").
      get("/")).
    pause(1)

  // Scenario configuration
  setUp(scn.inject(atOnceUsers(1))).protocols(httpConfig)
}
